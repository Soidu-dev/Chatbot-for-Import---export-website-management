package com.JSWchatbot.CHATBOT.repository;

import com.JSWchatbot.CHATBOT.entity.RoomsMaster;
import com.JSWchatbot.CHATBOT.entity.SnacksMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SnacksMasterRepository extends JpaRepository<SnacksMaster, Long> {
    Optional<SnacksMaster> findByRoomNo(String roomNo);

    Page<SnacksMaster> findAllByRecStatus(boolean recStatus, Pageable pageable);

    List<SnacksMaster> findAll(); // Default JpaRepository method to fetch all rooms
}

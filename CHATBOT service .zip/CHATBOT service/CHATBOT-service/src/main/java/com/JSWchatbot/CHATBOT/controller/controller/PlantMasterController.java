package com.JSWchatbot.CHATBOT.controller.controller;

import com.JSWchatbot.CHATBOT.dto.PlantMasterDTO;
import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.service.PlantMasterService;
import com.JSWchatbot.CHATBOT.service.VendorMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RestController
@RequestMapping("/plant")
@CrossOrigin
//@RequiredArgsConstructor
public class PlantMasterController {

    @Autowired
    PlantMasterService plantMasterService;

    @PostMapping("/save")
    public ResponseEntity<PlantMasterDTO> createPlant(@RequestBody PlantMasterDTO plantMasterDto) {
        return new ResponseEntity<>(plantMasterService.createPlant(plantMasterDto), HttpStatus.CREATED);
    }


}



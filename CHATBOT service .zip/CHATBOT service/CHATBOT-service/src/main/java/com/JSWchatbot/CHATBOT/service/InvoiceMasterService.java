package com.JSWchatbot.CHATBOT.service;

import com.JSWchatbot.CHATBOT.dto.InvoiceMasterDTO;
import com.JSWchatbot.CHATBOT.dto.PlantMasterDTO;
import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.entity.InvoiceMaster;
import com.JSWchatbot.CHATBOT.entity.PlantMaster;
import com.JSWchatbot.CHATBOT.entity.VendorMaster;
import com.JSWchatbot.CHATBOT.repository.InvoiceMasterRepository;
import com.JSWchatbot.CHATBOT.repository.PlantMasterRepository;
import com.JSWchatbot.CHATBOT.repository.VendorMasterRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
//@RequiredArgsConstructor
public class InvoiceMasterService {
    @Autowired
    ModelMapper mapper;
    @Autowired
    InvoiceMasterRepository invoiceMasterRepository;

    public InvoiceMasterDTO createInvoice(InvoiceMasterDTO invoiceDto) {
        InvoiceMaster invoiceObj = mapToEntity(invoiceDto);
        invoiceObj.setRecStatus(false);
        InvoiceMaster newInvoice = invoiceMasterRepository.save(invoiceObj);
        InvoiceMasterDTO invoiceResponse = mapToDTO(newInvoice);
        return invoiceResponse;
    }

    // convert Entity into DTO
    private InvoiceMasterDTO mapToDTO(InvoiceMaster invoice) {
        InvoiceMasterDTO invoiceDto = mapper.map(invoice, InvoiceMasterDTO.class);
        return invoiceDto;
    }

    // convert DTO to entity
    private InvoiceMaster mapToEntity(InvoiceMasterDTO invoiceDto) {
        InvoiceMaster invoiceObj = mapper.map(invoiceDto, InvoiceMaster.class);
        return invoiceObj;
    }
}
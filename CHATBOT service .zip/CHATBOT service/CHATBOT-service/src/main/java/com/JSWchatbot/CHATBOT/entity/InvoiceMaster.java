package com.JSWchatbot.CHATBOT.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "mstr_invoice", uniqueConstraints = {@UniqueConstraint(columnNames = {"currcode"})})
public class InvoiceMaster implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(name = "currcode", nullable = false)
    private String currcode;

    @Column(name = "description", nullable = false)
    private String description;


    @Column(name = "rec_status")
    private boolean recStatus;

}

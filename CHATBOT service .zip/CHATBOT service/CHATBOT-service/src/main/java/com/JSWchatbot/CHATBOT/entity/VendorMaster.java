package com.JSWchatbot.CHATBOT.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "mstr_vendor", uniqueConstraints = {@UniqueConstraint(columnNames = {"vendorcode"})})
public class VendorMaster implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(name = "vendorcode", nullable = false)
    private String vendorcode;

    @Column(name = "vendorname", nullable = false)
    private String vendorname;


    @Column(name = "ponumber")
    private String ponumber;

    @Column(name = "rec_status")
    private boolean recStatus;

}

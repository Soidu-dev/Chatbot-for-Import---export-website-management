package com.JSWchatbot.CHATBOT.service;

import com.JSWchatbot.CHATBOT.dto.PlantMasterDTO;
import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.entity.PlantMaster;
import com.JSWchatbot.CHATBOT.entity.VendorMaster;
import com.JSWchatbot.CHATBOT.repository.PlantMasterRepository;
import com.JSWchatbot.CHATBOT.repository.VendorMasterRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
//@RequiredArgsConstructor
public class PlantMasterService {
    @Autowired
    ModelMapper mapper;
    @Autowired
    PlantMasterRepository plantMasterRepository;

    public PlantMasterDTO createPlant(PlantMasterDTO plantDto) {
        PlantMaster plantObj = mapToEntity(plantDto);
        plantObj.setRecStatus(false);
        PlantMaster newPlant = plantMasterRepository.save(plantObj);
        PlantMasterDTO plantResponse = mapToDTO(newPlant);
        return plantResponse;
    }

    // convert Entity into DTO
    private PlantMasterDTO mapToDTO(PlantMaster plant) {
        PlantMasterDTO plantDto = mapper.map(plant, PlantMasterDTO.class);
        return plantDto;
    }

    // convert DTO to entity
    private PlantMaster mapToEntity(PlantMasterDTO plantDto) {
        PlantMaster plantObj = mapper.map(plantDto, PlantMaster.class);
        return plantObj;
    }
}
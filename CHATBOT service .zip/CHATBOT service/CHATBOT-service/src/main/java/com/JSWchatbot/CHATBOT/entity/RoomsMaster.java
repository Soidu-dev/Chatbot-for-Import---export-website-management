package com.JSWchatbot.CHATBOT.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "mstr_rooms", uniqueConstraints = {@UniqueConstraint(columnNames = {"roomNo"})})
public class RoomsMaster implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(name = "roomNo", nullable = false)
    private String roomNo;

    @Column(name = "organizerID")
    private String organizerID;


    @Column(name = "timeSlot")
    private String timeSlot;

    @Column(name = "description")
    private String description;


    @Column(name = "rec_status")
    private boolean recStatus;

}

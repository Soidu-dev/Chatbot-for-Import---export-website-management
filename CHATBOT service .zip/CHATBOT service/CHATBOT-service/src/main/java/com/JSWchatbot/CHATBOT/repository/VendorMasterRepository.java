package com.JSWchatbot.CHATBOT.repository;

import com.JSWchatbot.CHATBOT.entity.VendorMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VendorMasterRepository extends JpaRepository<VendorMaster, Long> {
    Optional<VendorMaster> findByPonumber(String ponumber);

    Page<VendorMaster> findAllByRecStatus(boolean recStatus, Pageable pageable);
}
package com.JSWchatbot.CHATBOT.controller;

import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.service.VendorMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RestController
@RequestMapping("/vendor")
@CrossOrigin
//@RequiredArgsConstructor
public class VendorMasterController {

    @Autowired
    VendorMasterService vendorMasterService;

    @PostMapping("/save")
    public ResponseEntity<VendorMasterDTO> createVendor(@RequestBody VendorMasterDTO vendorMasterDto) {
        return new ResponseEntity<>(vendorMasterService.createVendor(vendorMasterDto), HttpStatus.CREATED);
    }

        @PostMapping("/verify-email")
        public ResponseEntity<String> verifyEmail(@RequestBody Map<String, String> payload) {
            String email = payload.get("email");
            if (email != null && email.endsWith("@jsw.in")) {
                return ResponseEntity.ok("Email verified successfully!");
            }
            return ResponseEntity.badRequest().body("Invalid email domain.");
        }
    }



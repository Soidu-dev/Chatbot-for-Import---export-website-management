package com.JSWchatbot.CHATBOT.controller.controller;

import com.JSWchatbot.CHATBOT.dto.PlantMasterDTO;
import com.JSWchatbot.CHATBOT.dto.RoomsMasterDTO;
import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.service.PlantMasterService;
import com.JSWchatbot.CHATBOT.service.RoomsMasterService;
import com.JSWchatbot.CHATBOT.service.VendorMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/rooms")
@CrossOrigin
//@RequiredArgsConstructor
public class RoomsMasterController {

    @Autowired
    RoomsMasterService roomsMasterService;

    @PostMapping("/save")
    public ResponseEntity<RoomsMasterDTO> createRooms(@RequestBody RoomsMasterDTO roomsMasterDto) {
        return new ResponseEntity<>(roomsMasterService.createRooms(roomsMasterDto), HttpStatus.CREATED);
    }


    @GetMapping("/all")
    public ResponseEntity<List<RoomsMasterDTO>> fetchAllRooms() {
        List<RoomsMasterDTO> rooms = roomsMasterService.fetchAllRooms();
        return new ResponseEntity<>(rooms, HttpStatus.OK);
    }
}
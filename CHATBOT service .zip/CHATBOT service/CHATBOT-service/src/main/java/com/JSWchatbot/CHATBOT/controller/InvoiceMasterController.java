package com.JSWchatbot.CHATBOT.controller;

import com.JSWchatbot.CHATBOT.dto.InvoiceMasterDTO;
import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.service.InvoiceMasterService;
import com.JSWchatbot.CHATBOT.service.VendorMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/invoice")
@CrossOrigin
//@RequiredArgsConstructor
public class InvoiceMasterController {

    @Autowired
    InvoiceMasterService invoiceMasterService;

    @PostMapping("/save")
    public ResponseEntity<InvoiceMasterDTO> createInvoice(@RequestBody InvoiceMasterDTO invoiceMasterDto) {
        return new ResponseEntity<>(invoiceMasterService.createInvoice(invoiceMasterDto), HttpStatus.CREATED);
    }


}



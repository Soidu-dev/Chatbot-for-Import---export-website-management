package com.JSWchatbot.CHATBOT.service;

import com.JSWchatbot.CHATBOT.dto.PlantMasterDTO;
import com.JSWchatbot.CHATBOT.dto.RoomsMasterDTO;
import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.entity.PlantMaster;
import com.JSWchatbot.CHATBOT.entity.RoomsMaster;
import com.JSWchatbot.CHATBOT.entity.VendorMaster;
import com.JSWchatbot.CHATBOT.repository.PlantMasterRepository;
import com.JSWchatbot.CHATBOT.repository.RoomsMasterRepository;
import com.JSWchatbot.CHATBOT.repository.VendorMasterRepository;
import org.modelmapper.Converter;
import org.modelmapper.Converters;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
//@RequiredArgsConstructor
public class RoomsMasterService {
    @Autowired
    ModelMapper mapper;
    @Autowired
    RoomsMasterRepository roomsMasterRepository;



    public RoomsMasterDTO createRooms(RoomsMasterDTO roomsDto) {
        RoomsMaster roomsObj = mapToEntity(roomsDto);
        roomsObj.setRecStatus(false);
        RoomsMaster newRooms = roomsMasterRepository.save(roomsObj);
        RoomsMasterDTO roomsResponse = mapToDTO(newRooms);
        return roomsResponse;
    }

    // convert Entity into DTO
    private RoomsMasterDTO mapToDTO(RoomsMaster rooms) {
        RoomsMasterDTO roomsDto = mapper.map(rooms, RoomsMasterDTO.class);
        return roomsDto;
    }

    // convert DTO to entity
    private RoomsMaster mapToEntity(RoomsMasterDTO roomsDto) {
        RoomsMaster roomsObj = mapper.map(roomsDto, RoomsMaster.class);
        return roomsObj;
    }
    public List<RoomsMasterDTO> fetchAllRooms() {
        List<RoomsMaster> allRooms = roomsMasterRepository.findAll();
        return allRooms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
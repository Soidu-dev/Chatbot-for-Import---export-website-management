package com.JSWchatbot.CHATBOT.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "mstr_plant", uniqueConstraints = {@UniqueConstraint(columnNames = {"plantcode"})})
public class PlantMaster implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(name = "plantcode", nullable = false)
    private String plantcode;

    @Column(name = "plantname", nullable = false)
    private String plantname;


    @Column(name = "rec_status")
    private boolean recStatus;

}

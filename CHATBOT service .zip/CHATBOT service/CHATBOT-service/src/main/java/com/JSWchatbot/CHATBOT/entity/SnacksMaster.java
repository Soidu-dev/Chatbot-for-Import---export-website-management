package com.JSWchatbot.CHATBOT.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "mstr_snacks", uniqueConstraints = {@UniqueConstraint(columnNames = {"roomNo"})})
public class SnacksMaster implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(name = "roomNo", nullable = false)
    private String roomNo;

    @Column(name = "time")
    private String time;

    @ElementCollection
    @CollectionTable(name = "snack_items", joinColumns = @JoinColumn(name = "snack_id"))
    @Column(name = "snack")
    private List<String> snacks;

    @Column(name = "rec_status")
    private boolean recStatus;
}

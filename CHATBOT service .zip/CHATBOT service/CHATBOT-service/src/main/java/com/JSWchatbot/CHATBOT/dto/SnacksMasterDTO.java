package com.JSWchatbot.CHATBOT.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class SnacksMasterDTO implements Serializable {
    private String roomNo;
    private String time;
    private List<String> snacks;
}

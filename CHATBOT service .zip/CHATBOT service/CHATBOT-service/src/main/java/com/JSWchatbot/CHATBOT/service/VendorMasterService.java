package com.JSWchatbot.CHATBOT.service;

import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.entity.VendorMaster;
import com.JSWchatbot.CHATBOT.repository.VendorMasterRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
//@RequiredArgsConstructor
public class VendorMasterService {
    @Autowired
    ModelMapper mapper;
    @Autowired
    VendorMasterRepository vendorMasterRepository;

    public VendorMasterDTO createVendor(VendorMasterDTO vendorDto) {
        VendorMaster vendorObj = mapToEntity(vendorDto);
        vendorObj.setRecStatus(false);
        VendorMaster newVendor = vendorMasterRepository.save(vendorObj);
        VendorMasterDTO vendorResponse = mapToDTO(newVendor);
        return vendorResponse;
    }

    // convert Entity into DTO
    private VendorMasterDTO mapToDTO(VendorMaster vendor) {
        VendorMasterDTO vendorDto = mapper.map(vendor, VendorMasterDTO.class);
        return vendorDto;
    }

    // convert DTO to entity
    private VendorMaster mapToEntity(VendorMasterDTO vendorDto) {
        VendorMaster vendorObj = mapper.map(vendorDto, VendorMaster.class);
        return vendorObj;
    }
}
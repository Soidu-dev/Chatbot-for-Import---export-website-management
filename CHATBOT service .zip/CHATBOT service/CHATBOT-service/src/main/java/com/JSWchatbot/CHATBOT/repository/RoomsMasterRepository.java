package com.JSWchatbot.CHATBOT.repository;

import com.JSWchatbot.CHATBOT.entity.RoomsMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RoomsMasterRepository extends JpaRepository<RoomsMaster, Long> {
    Optional<RoomsMaster> findByRoomNo(String roomNo);

    Page<RoomsMaster> findAllByRecStatus(boolean recStatus, Pageable pageable);



    List<RoomsMaster> findAll(); // Default JpaRepository method to fetch all rooms
}

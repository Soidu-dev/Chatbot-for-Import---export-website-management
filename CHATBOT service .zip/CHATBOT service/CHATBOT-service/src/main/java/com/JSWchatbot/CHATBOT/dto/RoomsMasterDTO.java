package com.JSWchatbot.CHATBOT.dto;

import com.JSWchatbot.CHATBOT.entity.VendorMaster;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;

import java.io.Serializable;


@AllArgsConstructor
@NoArgsConstructor
@Data

public class RoomsMasterDTO implements Serializable {
    private String roomNo;
    private String organizerID;
    private String timeSlot;
    private String description;
}

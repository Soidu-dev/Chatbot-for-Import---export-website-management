package com.JSWchatbot.CHATBOT.service;

import com.JSWchatbot.CHATBOT.dto.PlantMasterDTO;
import com.JSWchatbot.CHATBOT.dto.RoomsMasterDTO;
import com.JSWchatbot.CHATBOT.dto.SnacksMasterDTO;
import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.entity.PlantMaster;
import com.JSWchatbot.CHATBOT.entity.RoomsMaster;
import com.JSWchatbot.CHATBOT.entity.SnacksMaster;
import com.JSWchatbot.CHATBOT.entity.VendorMaster;
import com.JSWchatbot.CHATBOT.repository.PlantMasterRepository;
import com.JSWchatbot.CHATBOT.repository.RoomsMasterRepository;
import com.JSWchatbot.CHATBOT.repository.SnacksMasterRepository;
import com.JSWchatbot.CHATBOT.repository.VendorMasterRepository;
import org.modelmapper.Converter;
import org.modelmapper.Converters;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
//@RequiredArgsConstructor
public class SnacksMasterService {
    @Autowired
    ModelMapper mapper;
    @Autowired
    SnacksMasterRepository snacksMasterRepository;



    public SnacksMasterDTO createSnacks(SnacksMasterDTO snacksDto) {
        SnacksMaster snacksObj = mapToEntity(snacksDto);
        snacksObj.setRecStatus(false);
        SnacksMaster newSnacks = snacksMasterRepository.save(snacksObj);
        SnacksMasterDTO snacksResponse = mapToDTO(newSnacks);
        return snacksResponse;
    }

    // convert Entity into DTO
    private SnacksMasterDTO mapToDTO(SnacksMaster snacks) {
        SnacksMasterDTO snacksDto = mapper.map(snacks, SnacksMasterDTO.class);
        return snacksDto;
    }

    // convert DTO to entity
    private SnacksMaster mapToEntity(SnacksMasterDTO snacksDto) {
        SnacksMaster snacksObj = mapper.map(snacksDto, SnacksMaster.class);
        return snacksObj;
    }
    public List<SnacksMasterDTO> fetchAllSnacks() {
        List<SnacksMaster> allRooms = snacksMasterRepository.findAll();
        return allRooms.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
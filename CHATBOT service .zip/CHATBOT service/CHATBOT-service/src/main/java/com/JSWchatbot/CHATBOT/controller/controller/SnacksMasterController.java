package com.JSWchatbot.CHATBOT.controller.controller;

import com.JSWchatbot.CHATBOT.dto.PlantMasterDTO;
import com.JSWchatbot.CHATBOT.dto.RoomsMasterDTO;
import com.JSWchatbot.CHATBOT.dto.SnacksMasterDTO;
import com.JSWchatbot.CHATBOT.dto.VendorMasterDTO;
import com.JSWchatbot.CHATBOT.service.PlantMasterService;
import com.JSWchatbot.CHATBOT.service.RoomsMasterService;
import com.JSWchatbot.CHATBOT.service.SnacksMasterService;
import com.JSWchatbot.CHATBOT.service.VendorMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/snacks")
@CrossOrigin
//@RequiredArgsConstructor
public class SnacksMasterController {

    @Autowired
    SnacksMasterService snacksMasterService;

    @PostMapping("/save")
    public ResponseEntity<SnacksMasterDTO> createSnacks(@RequestBody SnacksMasterDTO snacksMasterDto) {
        return new ResponseEntity<>(snacksMasterService.createSnacks(snacksMasterDto), HttpStatus.CREATED);
    }


    @GetMapping("/all")
    public ResponseEntity<List<SnacksMasterDTO>> fetchAllSnacks() {
        List<SnacksMasterDTO> snacks = snacksMasterService.fetchAllSnacks();
        return new ResponseEntity<>(snacks, HttpStatus.OK);
    }
}